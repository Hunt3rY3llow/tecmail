

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Bandeja de Mensajes</div>
                
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div><br>
                    <?php endif; ?>
                    <div>
                        <table class="table table-dark">
                        <tr>
                            <th>Remitente</th>
                            <th>Asunto</th>
                            <th>Mensaje</th>
                            <th>Prioridad</th>
                        </tr>
                         <?php $__empty_1 = true; $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensajesItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><a href="<?php echo e(route('NuevoMensaje.show',$mensajesItem)); ?>"><?php echo e($mensajesItem->co); ?></a></td>
                            <td><?php echo e($mensajesItem->asunto); ?></td>
                            <td><?php echo e($mensajesItem->mensaje); ?></td>
                            <td><?php echo e($mensajesItem->prioridad); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h1>Nada para mostrar</h1>
                        </tr>
                        <?php endif; ?>    
                    </div>
                    </table>
                        
                </div>
               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tecmail\resources\views/home.blade.php ENDPATH**/ ?>