
<?php $__env->startSection('content'); ?>

<div align="center">
	<?php if($mensaje): ?>
	<h1><?php echo e($mensaje['asunto']); ?></h1>
	<p><?php echo e($mensaje['mensaje']); ?></p>
		<?php if($mensaje['adjunto']): ?>
			<a href="<?php echo e(Storage::url($mensaje['adjunto'])); ?>">Ver Archivo adjunto</a>
		<?php endif; ?>
	<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tecmail\resources\views/VerMensaje.blade.php ENDPATH**/ ?>