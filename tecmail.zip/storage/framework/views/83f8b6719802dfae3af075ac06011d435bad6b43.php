

<?php $__env->startSection('content'); ?>

<p>Mensaje nuevo</p>
<form method="post"  enctype="multipart/form-data" action="<?php echo e(route('NuevoMensaje.store')); ?>">
   <?php echo csrf_field(); ?>
  <div class="form-group row">
    <label for="email" class="col-md-4 col-form-label text-md-right">De:</label>

    <div class="col-md-6">
      <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="emailO" value="<?php echo e(auth()->user()->email); ?>" autofocus readonly="readonly">

      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
      </span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>

  <div class="form-group row">
    <div id="destinos" class="col-md-12">
      <label for="email" >PARA:</label>
      <input type="email" name="email" required>
      
    </div>
  </div>

  <div class="col-md-4 col-form-label text-md-right">
    <label for="prioridad">Seleccione la prioridad del mesaje</label>
    <select name="prioridad" id="prioridad">
      <option>Informativo</option>
      <option >Normal</option>
      <option >Urgente</option>
    </select>
  </div>
  <div class="form-group row">
    <label for="mensaje" class="col-md-4 col-form-label text-md-right">Asunto:</label>

    <div class="col-md-6">

      <input id="mensaje" name="asunto" type="text" placeholder="Asunto del mensaje..." >
    </div>
  </div>
  <div class="col-md-4 col-form-label text-md-right">
    <textarea id="detalle" name="mensaje" rows="10" cols="90" placeholder="Escribe tu mensaje aqui..."></textarea>
  </div>

  <div class="form-group row">
   <label for="archivo" class="col-md-4 col-form-label text-md-right">Seleccionar archivo</label>

   <div class="col-md-6">

    <input id="archivo" name="archivo" type="file" multiple>
  </div>



 
  <button>Enviar</button>
</form>



<script>
function myFunction() {
  var x = document.createElement("INPUT");
  x.setAttribute("type", "email");
  x.setAttribute("name", "email");
  x.setAttribute("required", "true");
  x.setAttribute("value", "");
  document.getElementById('destinos').appendChild(x);
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tecmail\resources\views/NewMessage.blade.php ENDPATH**/ ?>