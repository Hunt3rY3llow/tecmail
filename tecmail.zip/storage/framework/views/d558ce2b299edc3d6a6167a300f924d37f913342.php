

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pastel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <table class="table table-dark">
                        <thead>
                            <tr>
                             <th scope="col">#</th>
                             <th scope="col">Nombre</th>
                             <th scope="col">Correo</th>
                             <th scope="col">Rol</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td ><?php echo e($pastel->id); ?></td>
                                <td class="text-center"><?php echo e($pastel->name); ?></td>
                                <td class="text-center"><?php echo e($pastel->email); ?></td>
                                <td class="text-center"><?php echo e($pastel->rol); ?></td>
                                <td class="text-center">
                                 <form action="<?php echo e(route('modificar.destroy', $pastel->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-info btn-xs" type="submit">Delete</button>
                </form>

            </td>
            <td>

                <a href="<?php echo e(url('/modificar/'.$pastel->id.'/edit')); ?>" class="btn btn-info btn-xs">
                    <span >Modificar</span>
                </a>
            </td>

                                 
        
                            </tr>
                        </tbody>
                    </table>
                      

            
            

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tecmail\resources\views/modificar.blade.php ENDPATH**/ ?>