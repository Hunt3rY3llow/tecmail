@extends('layouts.app')
@section('content')

<div align="center">
	@if($mensaje)
	<h1>{{$mensaje['asunto']}}</h1>
	<p>{{$mensaje['mensaje']}}</p>
		@if($mensaje['adjunto'])
			<a href="{{Storage::url($mensaje['adjunto'])}}">Ver Archivo adjunto</a>
		@endif
	@endif
</div>
@endsection